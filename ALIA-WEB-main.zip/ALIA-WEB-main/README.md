# ALIA
## Proyecto ALIA (Asistente Legal de Inteligencia Artificial)

El Proyecto *ALIA* es una plataforma de software diseñada para revolucionar la forma en que trabajamos en el campo legal, utilizando inteligencia artificial para proporcionar una herramienta más precisa, eficiente y accesible para los profesionales del derecho y eventualmente al público en general. Este proyecto tiene como objetivo ayudar a resolver problemas de razonamiento legal y proporcionar acceso a la justicia de manera más equitativa y transparente.

# Objetivos

- Crear una herramienta para profesionales del derecho que los ayude a navegar en el mundo de la jurisprudencia mexicana y el patrón histórico de razonamiento jurídico mexicano.

- Desarrollar una plataforma para resolver problemas legales complejos y proporcionar acceso a la justicia de manera más eficiente, precisa y accesible para el público en general.

- Optimizar modelos avanzados de inteligencia artificial, construyendo nuestra propia capa de entrenamiento por encima de otras capas preexistentes que representan patrones de lenguaje (ChatGPT) y razonamiento (GPT3.5/4).
Crear una herramienta que sea capaz de redactar documentos legales, demandas, contestaciones, amparos, etc.

- Expandir las capacidades del modelo para abarcar distintas tareas que son necesarias día con día en el ámbito legal.

- Buscar socios en la esfera pública y privada que puedan proveernos con datos de entrenamiento y feedback de usuarios.

# Fases del proyecto

El proyecto ALIA se dividirá en tres fases principales:

## Fase 1
En esta fase se desarrollará una herramienta para profesionales del derecho que los ayude a navegar en el mundo de la jurisprudencia mexicana. Esto nos permitirá enseñarle a nuestro modelo el patrón histórico de razonamiento jurídico mexicano. Esta fase es esencial para el desarrollo del proyecto, ya que proporcionará una base sólida para la expansión de las capacidades del modelo en las fases posteriores.

## Fase 2
En esta fase, nos enfocaremos en la expansión del modelo con diferentes tipos de datos que representen un mayor nivel de entendimiento a través de prompt engineering. También buscaremos socios valiosos en la industria privada que puedan proveernos con datos de entrenamiento y feedback de usuarios. Esta fase nos permitirá mejorar la precisión y eficiencia de la herramienta y proporcionar un mejor servicio al público en general.

## Fase 3
En esta fase, se expandirán las capacidades del modelo para abarcar distintas tareas que son necesarias día con día en el ámbito legal, como la redacción de documentos legales, demandas, contestaciones, amparos, etc. También se buscarán socios en la esfera pública para mejorar la eficiencia del servicio y proporcionar acceso a la justicia de manera más equitativa y transparente.
 

## Como correr el proyecto

- [ ] Clona el repositorio
- [ ] ve a la carpeta del proyecto

### Con Docker
    
#### Requerimientos
- [ ] Docker
- [ ] Docker-compose

```shell
docker-compose up
```

### Sin Docker

#### Requerimientos
- [ ] node 18.3
- [ ] npm

```shell
npm run dev
````

