import { type NextPage } from "next";
import Head from "next/head";
import { api } from "~/utils/api";
import Carousel from "~/Components/Carousel";

const Home: NextPage = () => {
  const hello = api.example.hello.useQuery({ text: "from tRPC" });

  // hacer que funcione el on hover y lo demas
  // 4. haremos commit a el trabajo y un pull request (pr)
  // 5. reestructuraremos los archivos y crearemos un componente que se llame carrousel, el cual contendra un array con la info de las cards como parametro
  return (
    <>
      <Head>
        <title>Create T3 App</title>
        <meta name="description" content="" />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <main className="h-screen w-screen bg-slate-700">
        <h1 className="">hola</h1>
        <Carousel />
      </main>
    </>
  );
};

export default Home;
